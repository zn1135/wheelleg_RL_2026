"""用已有测量和预测复核脚本合并；不训练、不仿真、不改写原产物。"""
import ast
import copy
import importlib
import hashlib
import json
import os
from pathlib import Path
import tarfile
import tempfile
import subprocess
from types import SimpleNamespace

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[3]
ARCHIVE = ROOT / 'scripts/archive/20261101-script-cleanup/source.tar.gz'


def original_functions(name, functions, namespace):
    with tarfile.open(ARCHIVE) as bundle:
        source = bundle.extractfile('scripts/agent/' + name + '.py').read().decode()
    nodes = [n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name in functions]
    assert len(nodes) == len(functions)
    scope = dict(namespace)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), name, 'exec'), scope)
    return scope


def same(left, right):
    if isinstance(left, torch.Tensor):
        assert left.dtype == right.dtype and left.shape == right.shape
        np.testing.assert_array_equal(left.cpu().numpy(), right.cpu().numpy())
    elif isinstance(left, dict):
        assert left.keys() == right.keys()
        for key in left:
            same(left[key], right[key])
    elif isinstance(left, (list, tuple)):
        assert len(left) == len(right)
        for a, b in zip(left, right):
            same(a, b)
    elif isinstance(left, float) and np.isnan(left):
        assert np.isnan(right)
    else:
        assert left == right, (left, right)


def contacts():
    from scripts.agent.stand_v2 import _contact_diagnostics as shared
    measurement = ROOT / 'artifacts/stand-v2-model499-diagnostic-20261027-final/measurements.npz'
    with np.load(measurement) as data:
        assert tuple(data['fields']) == shared.FIELDS
        values, active = data['values'], data['active']
    result = json.loads(measurement.with_name('result.json').read_text())
    late = active.copy()
    late[:max(0, round((result['duration_s'] - 5.) / result['policy_dt_s']))] = False
    for name in ('diagnose_chuanliantui_stand_v2', 'diagnose_stand_v2_rewards_velocity'):
        old = original_functions(name, ['contact_summary'], vars(shared))['contact_summary']
        for mask in (active, np.zeros_like(active)):
            same(old(values, mask, late & mask, result['policy_dt_s']),
                 shared.contact_summary(values, mask, late & mask, result['policy_dt_s']))
    return dict(source=str(measurement.relative_to(ROOT)), samples=int(values.shape[0]),
                environments=int(values.shape[1]), original_variants=2, empty_mask_checked=True)


def rounding():
    from scripts.agent.supermimic.check_supermimic_motion_retrain import norm_count_rounding_proof as check
    old = original_functions('check_supermimic_motion_retrain_counts', ['norm_count_rounding_proof'], {'torch': torch})['norm_count_rounding_proof']
    cases = [(100., 500., 10, 64), (7154886., 35774412., 6992, 1024)]
    for count, delta, steps, samples in cases:
        args = (torch.tensor(count), torch.tensor(delta), steps, samples)
        same(old(*args), check(*args))
    rejected = 0
    for count, delta, steps, samples in [(100., 501., 10, 64), (7154886., 35874412., 6992, 1024),
                                         (100., float('nan'), 10, 64), (100., 500., -1, 64)]:
        for function in (old, check):
            try:
                function(torch.tensor(count), torch.tensor(delta), steps, samples)
            except AssertionError:
                rejected += 1
            else:
                raise AssertionError('坏计数被接受')
    assert rejected == 8
    return dict(exact_and_rounded_cases=2, rejected_cases=4, original_implementation_equal=True)


def scoring():
    from scripts.agent.supermimic import _motion_scoring as shared
    saved_path = ROOT / 'artifacts/supermimic-v12-retrain-20261031-r1/score/predictions.pt'
    saved = torch.load(saved_path, map_location='cpu', weights_only=False, mmap=True)
    reports = []
    for name in ('score_supermimic_motion', 'score_supermimic_motion_retrain'):
        module = importlib.import_module('scripts.agent.supermimic.' + name)
        old = original_functions(name, ['predict', 'summarize'], vars(module))
        # 使用实际保存的预测和窗口；保留两个版本不同的指标集合。
        selected = [p for p in saved['predictions'] if p['world_label'] == saved['predictions'][0]['world_label']]
        for entry in selected:
            w = saved['windows'][entry['recording_index']]
            same(old['summarize'](entry['tensors'], w), module.summarize(entry['tensors'], w))
        # 空掩码、非有限预测必须保持原有拒计／计数方式。
        entry = selected[0]; w = copy.deepcopy(saved['windows'][entry['recording_index']])
        w['mask'].zero_(); pred = dict(entry['tensors']); pred['path'] = pred['path'].clone()
        pred['path'][0, 0, 0, 0] = float('nan')
        same(old['summarize'](pred, w), module.summarize(pred, w))
        reports.append(dict(variant=name, saved_prediction_groups=len(selected)))
    # 以保存的真实窗口驱动原/新预测循环；回放适配器不学习、不积分物理。
    window = saved['windows'][0]
    small = dict(plan=window['plan'][:3], mask=window['mask'][:3].clone(),
                 truth={k: v[:3].clone() for k, v in window['truth'].items()})
    small['mask'][1, 8:] = False
    class RecordedWorld:
        adapter = SimpleNamespace(continuation=lambda path: torch.isfinite(path).all(dim=(-2, -1)).float())

        def step(self, state, parameters, action, command, context, previous, previous_previous, noise, return_path):
            # 输出依赖调用传入量，能发现历史动作、命令、噪声传递顺序变化。
            updated = state + action.sum(-1, keepdim=True) * .001 + command.sum(-1, keepdim=True) * .002
            updated = updated + previous.sum(-1, keepdim=True) * .003 + previous_previous.sum(-1, keepdim=True) * .004
            updated = updated + noise.sum(-1, keepdim=True) * .005
            path = updated[..., :64].unsqueeze(1).expand(-1, 5, -1)
            return updated, updated[..., :25], updated.sum(-1), updated[..., 0] > 1., updated[..., :31], path
    for teacher in (False, True):
        for batch in (1, 3):
            same(old['predict'](RecordedWorld(), small, teacher, batch),
                 shared.predict(RecordedWorld(), small, teacher, batch))
    return dict(source=str(saved_path.relative_to(ROOT)), variants=reports,
                prediction_loop_cases=4, empty_mask_and_nonfinite_checked=True,
                scope='保存的预测张量与预测循环等价；未重新评分模型或运行物理。')


def provenance():
    from scripts.agent.stand import analyze_chuanliantui_stand as stand
    from scripts.agent.split import analyze_walk_velocity_compensation as velocity
    from scripts.agent.imitation.prepare_bc_wheel_dataset import snapshot_text
    old_path = 'scripts/agent/assess_chuanliantui_stand.py'
    sources = [dict(path='/historical/' + old_path, sha256='original-assessor')]
    sources += [dict(path='/historical/' + name, sha256=name) for name in stand.PROTOCOL_SOURCE_SUFFIXES[1:]]
    legacy = stand.protocol_sources(dict(sources=sources))
    assert all(legacy.values()), '旧报告丢失协议来源'
    relocated = copy.deepcopy(sources)
    relocated[0]['path'] = '/current/scripts/agent/stand/assess_chuanliantui_stand.py'
    same(legacy, stand.protocol_sources(dict(sources=relocated)))
    relocated[0]['sha256'] = 'changed-assessor'
    assert stand.protocol_sources(dict(sources=relocated)) != legacy
    proof = velocity.verify_candidate_source(ROOT / 'scripts/agent/split/walk_sensor_velocity.py')
    assert proof['original_sha256'] == velocity.EXPECTED_CANDIDATE_SHA256
    with tempfile.TemporaryDirectory() as directory:
        changed = Path(directory) / 'changed.py'
        changed.write_text((ROOT / 'scripts/agent/split/walk_sensor_velocity.py').read_text() + '\n# changed\n')
        try:
            velocity.verify_candidate_source(changed)
        except AssertionError:
            pass
        else:
            raise AssertionError('额外源码修改没有被拒绝')
        with tarfile.open(ARCHIVE) as bundle:
            for filename in ('collect_bc_braking.py', 'check_lqr_student_closed_loop.py'):
                original = bundle.extractfile('scripts/agent/' + filename).read()
                for prefix in ('scripts/agent/', 'scripts/agent/imitation/'):
                    key = prefix + filename
                    snapshot = Path(directory) / 'snapshot' / key
                    snapshot.parent.mkdir(parents=True, exist_ok=True)
                    snapshot.write_bytes(original)
                    report = dict(source_sha256={key: hashlib.sha256(original).hexdigest()})
                    assert snapshot_text(Path(directory), report, filename) == original.decode()
                    snapshot.write_bytes(original + b'\n# changed\n')
                    try:
                        snapshot_text(Path(directory), report, filename)
                    except AssertionError:
                        pass
                    else:
                        raise AssertionError('损坏的历史快照未被拒绝')
        # 替身解释器只核对工作目录和调度目标；不执行任何校准。
        fake = Path(directory) / 'python-path-check'
        fake.write_text('#!/usr/bin/env bash\nset -eu\n'
                        '[[ "$PWD" == "$EXPECTED_REPO" ]]\n'
                        r'if [[ "$1" == "-m" ]]; then test -f "${2//./\/}.py"; else test -f "$1"; fi' + '\n')
        fake.chmod(0o700)
        subprocess.run(['bash', str(ROOT / 'scripts/agent/real2sim/reproduce_fixed_h7_calibration.sh'),
                        str(Path(directory) / 'unused-output')], cwd=ROOT,
                       env=dict(os.environ, TASK_PYTHON=str(fake), EXPECTED_REPO=str(ROOT)), check=True)
    return dict(old_and_new_report_paths=True, changed_report_hash_not_equal=True,
                root_only_source_migration=proof, tampered_source_rejected=True,
                historical_snapshot_paths_and_hashes=True, shell_dispatch_without_calibration=True)


def main():
    torch.set_num_threads(2)
    print(json.dumps(dict(provenance=provenance(), contacts=contacts(), rounding=rounding(), scoring=scoring(),
                          training_updates=0, physics_steps=0), ensure_ascii=False))


if __name__ == '__main__':
    main()
