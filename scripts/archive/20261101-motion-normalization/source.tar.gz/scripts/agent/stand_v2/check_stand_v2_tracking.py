#!/usr/bin/env python3
"""Independently check delivered commands and summaries of saved stand_v2 tracking."""

import argparse
import json
from pathlib import Path

import numpy as np

from scripts.agent.stand_v2.assess_chuanliantui_stand_v2 import digest


def main(args):
    r = json.loads((args.measurement/"result.json").read_text())
    assert r["parameter_updates"] == 0 and r["actor_and_encoder_unchanged"]
    assert digest(r["checkpoint"]) == r["checkpoint_sha256"]
    for source, sha in r["sources"].items():
        assert digest(source) == sha, source
    assert digest(args.measurement/"trace.npz") == r["trace_sha256"]
    assert digest(args.measurement/"qpos.npz") == r["qpos_sha256"]
    with np.load(args.measurement/"trace.npz") as f:
        v, active, physical, ready = f["values"], f["active"], f["physical"], f["ready"]
        weight = f["weight_N"]
        assert v.shape == (2200, 64, 8) and physical.shape == (11000, 64, 15)
        assert np.allclose(f["time_s"], (np.arange(2200)+1)*.01)
        assert np.isfinite(v[active]).all()
        assert np.isfinite(physical[physical[:, :, 13] > .5]).all()
        if args.initial_reference:
            with np.load(args.initial_reference) as old:
                for key in ("initial_qpos", "initial_qvel", "weight_N"):
                    assert np.array_equal(old[key], f[key]), key
    assert not (np.diff(active.astype(int), axis=0) > 0).any()
    assert np.array_equal(ready, (v[799, :, 5] > .5) & (v[799, :, 6] < .5) & active[799])
    requested = np.array([row["requested_vx_m_s"] for row in r["rows"]], dtype=np.float32)
    expected = np.zeros((2200,64), dtype=np.float32)
    expected[800:1800] = np.where(ready, requested, 0.)
    assert np.array_equal(v[:, :, 0], expected), "Nonzero command did not reach the measurement window"
    assert (v[800:1800, :, 0] != 0).any(), "No nonzero command was delivered"
    tail = physical[5000:9000]
    balanced = ((tail[:, :, :2] >= np.maximum(.1*weight, 5.)[None, :, None]).all(-1)
        & (tail[:, :, :2].sum(-1) >= weight*.8) & (tail[:, :, :2].sum(-1) <= weight*1.2)
        & (tail[:, :, 2] <= 1.) & (tail[:, :, 3:5].max(-1) <= np.deg2rad(35.))
        & (tail[:, :, 5] <= .5) & (tail[:, :, 12] > .5) & (tail[:, :, 13] > .5))
    for i,row in enumerate(r["rows"]):
        if not row["ready_at_8s"]:
            assert row["actual_mean_vx_m_s"] is None and row["measured_s"] == 0.
            continue
        data = v[1000:1800, i][active[1000:1800, i]]
        assert np.isclose(row["actual_mean_vx_m_s"], data[:, 1].mean())
        assert np.isclose(row["vx_mean_abs_error_m_s"], np.abs(data[:, 1]-requested[i]).mean())
        assert np.isclose(row["steady_balance_fraction"], balanced[:, i].mean())
    for group in r["groups"]:
        rows = [row for row in r["rows"] if np.isclose(row["requested_vx_m_s"], group["command_vx_m_s"])]
        complete = [row for row in rows if row["complete_tracking_window"]]
        assert group["total"] == len(rows) and group["completed"] == len(complete)
        if complete:
            assert np.isclose(group["actual_mean_vx_m_s"], np.mean([row["actual_mean_vx_m_s"] for row in complete]))
            assert np.isclose(group["mean_abs_error_m_s"], np.mean([row["vx_mean_abs_error_m_s"] for row in complete]))
    result = dict(verified=True, checkpoint_sha256=r["checkpoint_sha256"],
        recorded_policy_steps=2200, recorded_physics_steps=11000,
        nonzero_command_delivered=True, original_64_initial_states_match=bool(args.initial_reference),
        ready_envs=int(ready.sum()), not_ready_envs=np.where(~ready)[0].tolist(),
        complete_tracking_envs=sum(row["complete_tracking_window"] for row in r["rows"]),
        final_drive_balanced_envs=sum(row["final_drive_balance_1s"] for row in r["rows"]),
        parameter_updates=0, source_sha256=digest(__file__))
    with args.output.open("x") as out:
        out.write(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--measurement", type=Path, required=True)
    parser.add_argument("--initial-reference", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
