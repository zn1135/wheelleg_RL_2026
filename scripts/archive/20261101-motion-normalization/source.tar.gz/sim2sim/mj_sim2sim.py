#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
imcawl 轮足机器人 sim2sim 部署验证脚本（Isaac Gym -> MuJoCo）

用途
    在 MuJoCo 里加载训练好的策略（mini_wheel_legged / imcawl 任务），复现训练时完全一致的
    观测构造、历史缓冲、动作->力矩映射与控制时序，验证策略脱离 Isaac Gym 后仍能站立/行走。
    这是通向真机部署的中间验证步骤，也是硬件端实现的参照蓝本。

关键契约（全部对齐 wheel_legged_gym/envs/base/legged_robot.py，勿改）
    - 策略：ActorCriticSequence。action = actor(cat(obs_27, encoder(history_135)))
      导出的 policy_1.pt 只含 actor、缺 encoder，不可用；因此直接加载 model_*.pt 完整权重。
    - DOF 顺序：[lf0, lf1, l_wheel, rf0, rf1, r_wheel]
    - 观测 27 维：[base_ang_vel*0.25(3), projected_gravity(3), cmd*[2.0,0.25,5.0](3),
                   (dof_pos-default)*1.0(6), dof_vel*0.05(6), last_action(6)]，裁剪 ±100
    - 历史 135=27*5：FIFO，最旧在前、最新在末尾；上电用首帧重复 5 次填充
    - dof_vel 用位置差分：wrap_to_pi(dof_pos-last_dof_pos)/sim_dt，每个 sim 子步更新一次
    - 动作->力矩：腿位置控制(Kp=60,Kd=2)，轮速度控制(Kp=0,Kd=0.5)；见 compute_torques()
    - 时序：sim_dt=0.005，decimation=2 -> 策略 100Hz，PD 内环 200Hz
    - 力矩上限：[30,30,5,30,30,5] N·m
    - 动作延迟：训练时随机化 0~10ms（action_fifo，每 env 固定 0/1/2 个 sim 步）；本脚本零延迟，
      在训练分布内。真机部署时通信+执行链路延迟须 <=10ms，超出即出分布。
    - 前进方向：imcawl 的腿装在机体 x 两侧、轮绕 x 轴滚动，前进方向是机体 +y（非 x）。
      cmd_vx 指的是"前向速度命令"（策略命令通道 0），对应机体系 vy。
    - yaw 命令通道是外环反馈不是常数：训练 heading_command=True，cmd[1]=1.5*(目标航向-
      当前航向) 剪 ±5、每步刷新。部署端（含真机）必须实现同样的航向保持外环，
      喂恒定 yaw 值会导致偏航漂移无人纠正、巡航数秒后摔（本脚本 --heading_hold 默认开）。

运行
    /home/zn/miniforge3/envs/wheellegged_py38/bin/python sim2sim/mj_sim2sim.py \
        --checkpoint logs/mini_wheel_legged/Jul20_12-42-47_/model_6900.pt --render
    先测站立：--cmd_vx 0 --cmd_height 0.30
    再测行走：--cmd_vx 1.0
    需要先在该环境安装 mujoco：pip install mujoco
"""

from __future__ import annotations

import argparse
import math
import os
import sys
import time

import numpy as np
import torch

# 允许从仓库根目录导入 wheel_legged_gym
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.dirname(_THIS_DIR)
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from wheel_legged_gym.rsl_rl.modules.actor_critic_sequence import ActorCriticSequence


# --------------------------------------------------------------------------------------
# 契约常量（全部已从 config / legged_robot.py 核实）
# --------------------------------------------------------------------------------------
JOINT_NAMES = ["lf0_joint", "lf1_joint", "l_wheel_joint",
               "rf0_joint", "rf1_joint", "r_wheel_joint"]
NUM_ACTIONS = 6
NUM_OBS = 27
# 特权观测维度（仅 critic 用，来自 legged_robot_config.py:42-44）：27 + 7*11 + 3 + 6*5 + 3 + 3 = 143
NUM_PRIVILEGED_OBS = 27 + 7 * 11 + 3 + 6 * 5 + 3 + 3  # 143
OBS_HISTORY_LENGTH = 5
NUM_ENCODER_OBS = NUM_OBS * OBS_HISTORY_LENGTH  # 135
LATENT_DIM = 3

DEFAULT_DOF_POS = np.array([0.9, -1.62, 0.0, -0.9, 1.62, 0.0], dtype=np.float64)
P_GAINS = np.array([60.0, 60.0, 0.0, 60.0, 60.0, 0.0], dtype=np.float64)
D_GAINS = np.array([2.0, 2.0, 0.5, 2.0, 2.0, 0.5], dtype=np.float64)
TORQUE_LIMITS = np.array([30.0, 30.0, 5.0, 30.0, 30.0, 5.0], dtype=np.float64)

POS_ACTION_SCALE = 0.5
VEL_ACTION_SCALE = 10.0

OBS_SCALE_ANG_VEL = 0.25
OBS_SCALE_DOF_POS = 1.0
OBS_SCALE_DOF_VEL = 0.05
# commands_scale = [lin_vel, ang_vel, height_measurements]
COMMANDS_SCALE = np.array([2.0, 0.25, 5.0], dtype=np.float64)

CLIP_OBS = 100.0
CLIP_ACTIONS = 100.0

SIM_DT = 0.005
DECIMATION = 2  # 策略 100Hz，PD 内环 200Hz

# 策略网络结构（来自 legged_robot_config.py:class policy）
ACTOR_HIDDEN_DIMS = [128, 64, 32]
CRITIC_HIDDEN_DIMS = [256, 128, 64]
ENCODER_HIDDEN_DIMS = [128, 64]

DEFAULT_CHECKPOINT = os.path.join(
    _REPO_ROOT, "logs", "mini_wheel_legged", "Jul20_12-42-47_", "model_6900.pt"
)
DEFAULT_MODEL_XML = os.path.join(_THIS_DIR, "imcawl.xml")


# --------------------------------------------------------------------------------------
# 数学工具（自实现，避免依赖 isaacgym，使脚本可独立运行）
# --------------------------------------------------------------------------------------
def quat_rotate_inverse(q_xyzw: np.ndarray, v: np.ndarray) -> np.ndarray:
    """把世界系向量 v 旋转到机体系（等价于 isaacgym.quat_rotate_inverse）。

    q_xyzw: [x, y, z, w]（与 Isaac Gym root_states[3:7] 一致）
    v:      [3]
    公式与 isaacgym.torch_utils.quat_rotate_inverse 完全一致。
    """
    q_vec = q_xyzw[:3]
    q_w = q_xyzw[3]
    a = v * (2.0 * q_w**2 - 1.0)
    b = np.cross(q_vec, v) * (2.0 * q_w)
    c = q_vec * (2.0 * np.dot(q_vec, v))
    return a - b + c


def wrap_to_pi(x: np.ndarray) -> np.ndarray:
    """把角度差绕到 [-pi, pi)，与 legged_robot.compute_dof_vel 的 remainder 逻辑一致。"""
    return np.remainder(x + math.pi, 2.0 * math.pi) - math.pi


def quat_wxyz_to_xyzw(q_wxyz: np.ndarray) -> np.ndarray:
    """MuJoCo 四元数为 [w,x,y,z]，转成 Isaac Gym 用的 [x,y,z,w]。"""
    return np.array([q_wxyz[1], q_wxyz[2], q_wxyz[3], q_wxyz[0]], dtype=np.float64)


# --------------------------------------------------------------------------------------
# 策略加载
# --------------------------------------------------------------------------------------
def load_policy(checkpoint_path: str, device: str = "cpu") -> ActorCriticSequence:
    """用仓库的 ActorCriticSequence 类重建网络并载入 model_*.pt 权重。"""
    ac = ActorCriticSequence(
        num_obs=NUM_OBS,
        num_critic_obs=NUM_PRIVILEGED_OBS + LATENT_DIM,  # 143+3=146（仅 critic 用，推理不涉及）
        num_actions=NUM_ACTIONS,
        num_encoder_obs=NUM_ENCODER_OBS,
        latent_dim=LATENT_DIM,
        encoder_hidden_dims=ENCODER_HIDDEN_DIMS,
        actor_hidden_dims=ACTOR_HIDDEN_DIMS,
        critic_hidden_dims=CRITIC_HIDDEN_DIMS,
        activation="elu",
    )
    ckpt = torch.load(checkpoint_path, map_location=device)
    if "model_state_dict" not in ckpt:
        raise KeyError(
            f"{checkpoint_path} 不含 model_state_dict；请使用 logs/.../model_*.pt 完整 checkpoint，"
            f"而非导出的 policy_1.pt。"
        )
    ac.load_state_dict(ckpt["model_state_dict"])
    ac.to(device)
    ac.eval()
    return ac


# --------------------------------------------------------------------------------------
# 观测构造与力矩计算（严格对齐 legged_robot.py）
# --------------------------------------------------------------------------------------
def build_obs(base_quat_xyzw, base_ang_vel_body, dof_pos, dof_vel, commands, last_action):
    """构造 27 维本体观测，顺序/缩放严格对齐 compute_proprioception_observations。

    注意：base_ang_vel_body 已是机体系角速度（由 mj_objectVelocity local 帧取得），
    无需再做 quat_rotate_inverse。projected_gravity 才需要把世界重力转到机体系。
    """
    gravity_world = np.array([0.0, 0.0, -1.0], dtype=np.float64)
    projected_gravity = quat_rotate_inverse(base_quat_xyzw, gravity_world)

    obs = np.concatenate([
        base_ang_vel_body * OBS_SCALE_ANG_VEL,            # 3
        projected_gravity,                                # 3 (无缩放)
        commands[:3] * COMMANDS_SCALE,                    # 3
        (dof_pos - DEFAULT_DOF_POS) * OBS_SCALE_DOF_POS,  # 6
        dof_vel * OBS_SCALE_DOF_VEL,                      # 6
        last_action,                                      # 6 (原始未缩放)
    ]).astype(np.float64)
    obs = np.clip(obs, -CLIP_OBS, CLIP_OBS)
    return obs


def compute_torques(action, dof_pos, dof_vel):
    """动作->关节力矩，严格对齐 legged_robot._compute_torques。

    腿关节(0,1,3,4)：位置控制，目标角 = action*0.5 + default。
    轮关节(2,5)：速度控制，目标速度 = action*10.0，Kp=0。
    """
    action = np.clip(action, -CLIP_ACTIONS, CLIP_ACTIONS)

    pos_ref = action * POS_ACTION_SCALE
    pos_ref[2] = 0.0
    pos_ref[5] = 0.0

    vel_ref = action * VEL_ACTION_SCALE
    vel_ref[0] = 0.0
    vel_ref[1] = 0.0
    vel_ref[3] = 0.0
    vel_ref[4] = 0.0

    torques = P_GAINS * (pos_ref + DEFAULT_DOF_POS - dof_pos) + D_GAINS * (vel_ref - dof_vel)
    return np.clip(torques, -TORQUE_LIMITS, TORQUE_LIMITS)


# --------------------------------------------------------------------------------------
# 主循环
# --------------------------------------------------------------------------------------
def run(args):
    import mujoco

    if not os.path.isfile(args.checkpoint):
        raise FileNotFoundError(f"checkpoint 不存在: {args.checkpoint}")
    if not os.path.isfile(args.model_xml):
        raise FileNotFoundError(f"MJCF 不存在: {args.model_xml}")

    device = "cpu"
    policy = load_policy(args.checkpoint, device=device)
    print(f"已加载策略: {args.checkpoint}")

    model = mujoco.MjModel.from_xml_path(args.model_xml)
    data = mujoco.MjData(model)
    model.opt.timestep = SIM_DT
    if args.friction is not None:
        # MuJoCo 接触摩擦取两 geom 的逐元素最大值；统一改滑动摩擦即可控制轮地摩擦。
        # 训练等效摩擦区间约 [0.4, 1.0]（机器人 [0.3,1.5] 与地面 0.5 取 PhysX 平均），均值 0.75。
        model.geom_friction[:, 0] = args.friction
        print(f"已覆盖所有 geom 滑动摩擦 = {args.friction}")
    print(f"已加载 MuJoCo 模型: {args.model_xml}  (nq={model.nq}, nv={model.nv}, nu={model.nu})")

    # 解析 6 个受控关节在 qpos/qvel/ctrl 里的地址
    qpos_adr = np.zeros(NUM_ACTIONS, dtype=np.int32)
    dof_adr = np.zeros(NUM_ACTIONS, dtype=np.int32)
    act_adr = np.zeros(NUM_ACTIONS, dtype=np.int32)
    for i, name in enumerate(JOINT_NAMES):
        jid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        if jid < 0:
            raise RuntimeError(f"MJCF 中找不到关节: {name}")
        qpos_adr[i] = model.jnt_qposadr[jid]
        dof_adr[i] = model.jnt_dofadr[jid]
        aid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
        if aid < 0:
            raise RuntimeError(f"MJCF 中找不到执行器: {name}")
        act_adr[i] = aid

    # 基座 free joint 地址（qpos 前 7 位 = pos(3)+quat wxyz(4)，qvel 前 6 位 = linvel(3)+angvel(3)）
    base_jid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "floating_base")
    base_qadr = model.jnt_qposadr[base_jid]
    base_vadr = model.jnt_dofadr[base_jid]

    # 初始姿态：基座高度 + 默认关节角
    mujoco.mj_resetData(model, data)
    data.qpos[base_qadr + 2] = args.init_height
    data.qpos[base_qadr + 3:base_qadr + 7] = np.array([1.0, 0.0, 0.0, 0.0])  # wxyz 单位四元数
    for i in range(NUM_ACTIONS):
        data.qpos[qpos_adr[i]] = DEFAULT_DOF_POS[i]
    mujoco.mj_forward(model, data)

    # 命令 [vx, yaw_rate, height]；vx/yaw 经 cmd_delay 后在 cmd_ramp 秒内线性爬升到目标
    commands_target = np.array([args.cmd_vx, args.cmd_yaw, args.cmd_height], dtype=np.float64)

    def commands_at(t: float) -> np.ndarray:
        factor = np.clip((t - args.cmd_delay) / max(args.cmd_ramp, 1e-6), 0.0, 1.0)
        return np.array([commands_target[0] * factor,
                         commands_target[1] * factor,
                         commands_target[2]], dtype=np.float64)

    commands = commands_at(0.0)

    # ---- 键盘遥操作（--teleop）----
    # viewer 线程回调里改、主循环里读；纯 float 赋值受 GIL 保护，无需加锁。
    kb = {"vx": 0.0, "heading": args.cmd_yaw, "height": args.cmd_height, "reset": False}

    def key_callback(keycode):
        # 注意：viewer 内置大量单字母快捷键（W线框/S阴影/R反射/数字键组显隐...）且无法拦截，
        # 故遥操作只用方向键/PgUp/PgDn/空格等不冲突的键。
        if not args.teleop:
            return
        if keycode == 265:            # ↑ 加速
            # 上限 1.5 = 当前策略安全包线（encoder 高速估计偏置，1.8 会瞬态发散翻车，
            # 详见 2026-07-21 排查：Isaac cmd 1.8 真实速度也只到 ~1.5）
            kb["vx"] = min(kb["vx"] + 0.1, 1.5)
        elif keycode == 264:          # ↓ 减速（可到倒车）
            kb["vx"] = max(kb["vx"] - 0.1, -1.5)
        elif keycode == 263:          # ← 左转（航向目标 +）
            kb["heading"] = float(wrap_to_pi(np.array(kb["heading"] + 0.2)))
        elif keycode == 262:          # → 右转
            kb["heading"] = float(wrap_to_pi(np.array(kb["heading"] - 0.2)))
        elif keycode == 266:          # PgUp 升高
            kb["height"] = min(kb["height"] + 0.02, 0.40)
        elif keycode == 267:          # PgDn 降低
            kb["height"] = max(kb["height"] - 0.02, 0.20)
        elif keycode in (32, 257):    # 空格 / 回车 急停
            kb["vx"] = 0.0
        elif keycode == 268:          # Home 复位（viewer 无此绑定，干净无副作用）
            kb["reset"] = True
            print("[遥操作] 复位请求...")
            return
        else:
            return
        print(f"[遥操作] vx={kb['vx']:+.1f} m/s  航向={math.degrees(kb['heading']):+.0f}°  "
              f"高度={kb['height']:.2f} m")

    # 状态缓冲
    last_action = np.zeros(NUM_ACTIONS, dtype=np.float64)
    last_dof_pos = np.array([data.qpos[qpos_adr[i]] for i in range(NUM_ACTIONS)], dtype=np.float64)
    dof_vel = np.zeros(NUM_ACTIONS, dtype=np.float64)

    def read_dof_pos():
        return np.array([data.qpos[qpos_adr[i]] for i in range(NUM_ACTIONS)], dtype=np.float64)

    base_bid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "base_link")

    def read_base_state():
        quat_wxyz = data.qpos[base_qadr + 3:base_qadr + 7].copy()
        base_quat_xyzw = quat_wxyz_to_xyzw(quat_wxyz)
        # 注意：必须用 mjOBJ_XBODY（机体系 xmat/xpos）！mjOBJ_BODY 返回的是惯性主轴系
        # （ximat/xipos）的速度——base 惯量特征值降序排布导致主轴系相对机体系是轴置换，
        # 用 BODY 会把陀螺仪三分量整个换位喂给策略（2026-07-21 排查：站立勉强靠
        # projected_gravity 撑住、一加速就翻车的根因）。
        vel6 = np.zeros(6, dtype=np.float64)
        mujoco.mj_objectVelocity(model, data, mujoco.mjtObj.mjOBJ_XBODY, base_bid, vel6, 1)
        base_ang_vel_body = vel6[:3].copy()
        base_lin_vel_body = vel6[3:].copy()
        return base_quat_xyzw, base_ang_vel_body, base_lin_vel_body

    # obs_history：上电用首帧重复填充（对齐 reset_idx）
    dof_pos = read_dof_pos()
    base_quat_xyzw, base_ang_vel_body, base_lin_vel_body = read_base_state()
    first_obs = build_obs(base_quat_xyzw, base_ang_vel_body, dof_pos, dof_vel, commands, last_action)
    obs_history = np.tile(first_obs, OBS_HISTORY_LENGTH).astype(np.float64)  # 135

    viewer = None
    if args.render:
        try:
            import mujoco.viewer
            viewer = mujoco.viewer.launch_passive(model, data, key_callback=key_callback)
        except Exception as e:  # noqa: BLE001
            print(f"警告：无法启动 viewer（{e}）；改为无渲染运行。")
            viewer = None
    if args.teleop:
        if viewer is None:
            raise RuntimeError("遥操作模式需要 --render（viewer 启动失败或未开启）")
        print("遥操作模式：点击 MuJoCo 窗口获得焦点后按键控制 —— "
              "↑ 加速 0.1 | ↓ 减速 | ← 左转 | → 右转 | PgUp/PgDn 升降高度 | 空格/回车 急停 | "
              "Home 复位。（字母键是 viewer 内置渲染快捷键，勿用）关闭窗口退出。")

    n_policy_steps = int(args.sim_time / (SIM_DT * DECIMATION))
    if args.teleop:
        n_policy_steps = 2 ** 31  # 遥操作不限时长，关窗退出
    print(f"开始仿真：{args.sim_time}s -> {n_policy_steps} 个策略步 "
          f"(vx={args.cmd_vx}, yaw={args.cmd_yaw}, height={args.cmd_height})")
    print("日志字段说明：")
    print("  [步号]   策略步序号（100Hz，100 步 = 1 秒）")
    print("  y        基座世界系 y 坐标 [m]（imcawl 前进方向，位置在涨=在前移）")
    print("  z        基座离地高度 [m]（应贴住 cmd_height；跌到 ~0.12 = 翻倒扣在基座盒上）")
    print("  v_fwd    机体系前向速度 [m/s]（mj_objectVelocity 读取，应跟住 cmd_vx）")
    print("  vy_w     世界系 y 向速度 [m/s]（qvel 直读；与 v_fwd 应接近，差得远=速度读取有问题）")
    print("  轮速l/r  左/右轮等效线速度 [m/s]（轮角速度*半径0.0625；无打滑时应≈车速，")
    print("           远大于车速=轮子打滑空转，远小于=机器人在蹭移而轮子没滚）")
    print("  pg_yz    重力在机体系的投影 y/z 分量（直立=[0,-1]；pg_y 偏离 0 = 前后倾，")
    print("           持续增大 = 正在倾倒；pg_z 变正 = 已完全翻转）")
    print("  |a|max   6 维动作绝对值最大者（正常 <1，持续增长/饱和 = 策略在挣扎）")

    policy_dt = SIM_DT * DECIMATION  # 每个策略步对应的仿真时间（0.01s）
    wall_start = time.perf_counter()

    for step in range(n_policy_steps):
        # ---- 遥操作复位（Home 键）：回物理初始状态并清空控制器/历史缓冲 ----
        if args.teleop and kb["reset"]:
            kb["reset"] = False
            mujoco.mj_resetData(model, data)
            data.qpos[base_qadr + 2] = args.init_height
            data.qpos[base_qadr + 3:base_qadr + 7] = np.array([1.0, 0.0, 0.0, 0.0])
            for i in range(NUM_ACTIONS):
                data.qpos[qpos_adr[i]] = DEFAULT_DOF_POS[i]
            mujoco.mj_forward(model, data)
            last_action = np.zeros(NUM_ACTIONS, dtype=np.float64)
            last_dof_pos = read_dof_pos()
            dof_pos = last_dof_pos.copy()
            dof_vel = np.zeros(NUM_ACTIONS, dtype=np.float64)
            kb["vx"] = 0.0
            kb["heading"] = 0.0
            base_quat_xyzw, base_ang_vel_body, base_lin_vel_body = read_base_state()
            obs_history = np.tile(
                build_obs(base_quat_xyzw, base_ang_vel_body, dof_pos, dof_vel,
                          np.array([0.0, 0.0, kb["height"]]), last_action),
                OBS_HISTORY_LENGTH).astype(np.float64)
            print("[遥操作] 已复位（速度/航向清零，obs 历史按上电逻辑重填）")

        # ---- 策略推理（100Hz）----
        if args.teleop:
            commands = np.array([kb["vx"], 0.0, kb["height"]], dtype=np.float64)
            heading_target = kb["heading"]
        else:
            commands = commands_at(step * policy_dt)
            heading_target = args.cmd_yaw
        # 关键：mj_step 只积分不刷新派生量，cvel 停留在上一子步（5ms 前）。
        # 不刷新的话 mj_objectVelocity 读到的角速度（策略的陀螺仪观测）滞后 5ms，
        # 静态站立无感，加速瞬态的快俯仰动力学会因此欠阻尼而向后掀翻。
        mujoco.mj_forward(model, data)
        dof_pos = read_dof_pos()
        base_quat_xyzw, base_ang_vel_body, base_lin_vel_body = read_base_state()
        if args.heading_hold:
            # 对齐训练 heading_command=True（legged_robot.py:625-630）：yaw 命令通道不是常数，
            # 而是航向误差反馈 cmd[1]=clip(1.5*(目标航向-当前航向), ±5)，每步刷新。
            # 策略在训练中始终观测到这个外环反馈并依赖它纠偏；喂恒 0 会导致偏航漂移
            # 无人纠正、巡航数秒后航向偏出而摔（2026-07-21 排查结论）。
            # 航向定义对齐训练 forward_vec=[1,0,0]：机体 x 轴的世界方位角。
            qx, qy, qz, qw = base_quat_xyzw
            heading = math.atan2(2.0 * (qx * qy + qw * qz), 1.0 - 2.0 * (qy * qy + qz * qz))
            commands[1] = float(np.clip(
                1.5 * wrap_to_pi(np.array(heading_target - heading)), -5.0, 5.0))
        obs = build_obs(base_quat_xyzw, base_ang_vel_body, dof_pos, dof_vel, commands, last_action)

        # 历史 FIFO：丢最旧、末尾追加最新（对齐 legged_robot.py:395-398）
        obs_history = np.concatenate([obs_history[NUM_OBS:], obs])

        with torch.no_grad():
            obs_t = torch.from_numpy(obs).float().unsqueeze(0)
            hist_t = torch.from_numpy(obs_history).float().unsqueeze(0)
            action_t, latent_t = policy.act_inference(obs_t, hist_t)
        action = action_t.squeeze(0).cpu().numpy().astype(np.float64)
        # latent 前 3 维被训练监督为 base_lin_vel*2.0（ppo.py:265，lin_vel scale=2），
        # latent[1]/2 = 策略内部估计的前向速度，用于诊断"策略以为的速度"是否失真
        latent = latent_t.squeeze(0).cpu().numpy().astype(np.float64)

        # ---- PD 内环（200Hz），顺序严格对齐训练：算力矩 -> 步进 -> 刷新 pos/vel ----
        # 训练每子步是 simulate 后 compute_dof_vel（legged_robot.py:111-115），最后一个
        # 子步结束时 dof_vel 是最新后向差分；若在步进前差分（旧写法），obs 里的
        # dof_vel（含轮速里程计）会滞后一个子步 5ms，与陀螺仪滞后是同款问题。
        for _ in range(DECIMATION):
            torque = compute_torques(action, dof_pos, dof_vel)
            for i in range(NUM_ACTIONS):
                data.ctrl[act_adr[i]] = torque[i]
            mujoco.mj_step(model, data)
            dof_pos = read_dof_pos()
            dof_vel = wrap_to_pi(dof_pos - last_dof_pos) / SIM_DT
            last_dof_pos = dof_pos.copy()

        last_action = action

        if viewer is not None:
            if not viewer.is_running():
                print("viewer 已关闭，退出。")
                break
            viewer.sync()
            # 实时节流：让仿真按真实时间播放，便于观察（--realtime，默认开）
            if args.realtime:
                target = wall_start + (step + 1) * policy_dt
                sleep_t = target - time.perf_counter()
                if sleep_t > 0:
                    time.sleep(sleep_t)

        if step % args.log_every == 0:
            base_z = data.qpos[base_qadr + 2]
            base_y = data.qpos[base_qadr + 1]
            # 双源速度交叉验证：机体系(objectVelocity) vs 世界系(qvel)；yaw≈0 时两者应接近
            v_fwd = base_lin_vel_body[1]
            vy_world = data.qvel[base_vadr + 1]
            # 姿态（重力投影）与轮速：判断是否在前倾、轮子是否打滑（轮速*0.0625 应≈车速）
            gravity_world = np.array([0.0, 0.0, -1.0])
            pg = quat_rotate_inverse(base_quat_xyzw, gravity_world)
            wl = dof_vel[2] * 0.0625
            wr = dof_vel[5] * 0.0625
            print(f"[{step:5d}] y={base_y:+.3f} z={base_z:.3f} v_fwd={v_fwd:+.3f} "
                  f"v̂={latent[1]/2.0:+.3f} vy_w={vy_world:+.3f} "
                  f"轮速l/r={wl:+.2f}/{wr:+.2f}m/s "
                  f"pg_yz=[{pg[1]:+.2f},{pg[2]:+.2f}] yaw令={commands[1]:+.2f} "
                  f"|a|max={np.abs(action).max():.3f}")

    print("仿真结束。")
    if viewer is not None and viewer.is_running() and args.hold:
        print("仿真已结束，窗口保持打开（可继续拖动观察）。手动关闭窗口即退出。")
        while viewer.is_running():
            viewer.sync()
            time.sleep(0.02)
    if viewer is not None:
        viewer.close()


def selfcheck(args):
    """策略等价性/形状自检：喂零输入，确认 act_inference 输出 (1,6)。"""
    policy = load_policy(args.checkpoint, device="cpu")
    obs = torch.zeros(1, NUM_OBS)
    hist = torch.zeros(1, NUM_ENCODER_OBS)
    with torch.no_grad():
        action, latent = policy.act_inference(obs, hist)
    print(f"自检通过：action.shape={tuple(action.shape)} latent.shape={tuple(latent.shape)}")
    assert action.shape == (1, NUM_ACTIONS), action.shape
    assert latent.shape == (1, LATENT_DIM), latent.shape
    print(f"零输入下 action = {action.squeeze(0).numpy()}")


def main():
    p = argparse.ArgumentParser(description="imcawl MuJoCo sim2sim 部署验证")
    p.add_argument("--checkpoint", default=DEFAULT_CHECKPOINT, help="model_*.pt 完整 checkpoint 路径")
    p.add_argument("--model_xml", default=DEFAULT_MODEL_XML, help="MJCF 模型路径")
    p.add_argument("--render", action="store_true", help="启动 MuJoCo passive viewer")
    p.add_argument("--cmd_vx", type=float, default=0.0, help="目标前向线速度 [m/s]")
    p.add_argument("--cmd_yaw", type=float, default=0.0,
                   help="heading_hold 开(默认)：目标航向角 [rad]；关：偏航角速度命令 [rad/s]")
    p.add_argument("--cmd_height", type=float, default=0.30, help="目标机身高度 [m]")
    p.add_argument("--cmd_delay", type=float, default=3.0,
                   help="速度/偏航命令延迟生效时间 [s]（先站稳再动，高度命令不受影响）")
    p.add_argument("--cmd_ramp", type=float, default=1.0,
                   help="速度/偏航命令线性爬升时长 [s]（0=阶跃）")
    p.add_argument("--friction", type=float, default=None,
                   help="覆盖所有 geom 的滑动摩擦系数（默认用 XML 里的 0.5；训练等效均值约 0.75）")
    p.add_argument("--init_height", type=float, default=0.32, help="初始基座高度 [m]（与训练 init_state.pos z=0.32 一致）")
    p.add_argument("--sim_time", type=float, default=20.0, help="仿真时长 [s]")
    p.add_argument("--log_every", type=int, default=100, help="每多少策略步打印一次")
    p.add_argument("--selfcheck", action="store_true", help="仅做策略形状自检，不跑仿真")
    p.add_argument("--no_realtime", dest="realtime", action="store_false",
                   help="关闭实时节流（默认按真实时间播放，便于观察）")
    p.add_argument("--no_hold", dest="hold", action="store_false",
                   help="仿真结束后不保持窗口（默认保持，直到手动关闭）")
    p.add_argument("--no_heading_hold", dest="heading_hold", action="store_false",
                   help="关闭航向保持外环（训练是 heading 模式、yaw 通道=航向误差反馈；"
                        "关闭后 cmd_yaw 恒值直喂，偏航漂移将无人纠正，仅调试用）")
    p.add_argument("--teleop", action="store_true",
                   help="键盘遥操作（需 --render）：↑ 加速 ↓ 减速 ← 左转 → 右转 "
                        "PgUp/PgDn 升降高度 空格/回车急停 Home 复位；关窗退出")
    p.set_defaults(realtime=True, hold=True, heading_hold=True)
    args = p.parse_args()

    if args.selfcheck:
        selfcheck(args)
    else:
        run(args)


if __name__ == "__main__":
    main()
